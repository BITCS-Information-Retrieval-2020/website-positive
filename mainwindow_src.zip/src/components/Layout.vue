<template>
  <div class="bannerSelectInput">
    <el-row  :gutter="0">
      <el-col :span="20">
        <div class="grid-content bg-purple-light">
          <el-input placeholder="请输入内容" v-model="input3" class="input-with-select">
            <el-select v-model="value"  slot="prepend" multiple placeholder="请选择">
              <el-option
                v-for="item in cities"
                :key="item.value"
                :label="item.label"
                :value="item.value">
                <span style="float: left">{{ item.label }}</span>
                <span style="float: right; color: #8492a6; font-size: 13px">{{ item.value }}</span>
              </el-option>
            </el-select>
          </el-input>
        </div>
      </el-col>
      <el-col :span="2">
        <div class="grid-content bg-purple-light">
          <el-button class="bor" type="primary" icon="el-icon-search" @click="bannersearchbtn">搜索</el-button>
        </div>
      </el-col>
    </el-row>
  </div>
</template>
<style>
.el-select .el-input {
  width: 200px;
}
.input-with-select .el-input-group__prepend {
  background-color: #fff;
}
.bannerSelectInput {
   width: 45%;
   height: 70px;
   border: 1px solid rgb(218, 218, 218);
   border-radius: 5px;
   position: relative;
   top: 40%;
   left: 25%;
   z-index: 3;
   /* banner上面的input */
   padding-top: 30px;
   padding-left: 10px;
   background-color: rgba(0, 0, 0, 0.3);
 }


</style>
<script>
export default {
  name: 'banner',
  data() {
    return {
      input3: '',
      select: '',
      cities: [{
        value: 'Whole',
        label: '全部'
      }, {
        value: 'Title',
        label: '标题'
      }, {
        value: 'Author',
        label: '作者'
      }, {
        value: 'Abstract',
        label: '摘要'
      }],
      value: ''
    }
  },
  methods: {
    bannersearchbtn() {
      if (this.input == '') {
        this.$message({
          message: '不能是空的哦，输入你要查询的内容吧',
          type: 'warning'
        })
      } else {
        console.log(this.input);
      }
    }
  },
}
</script>

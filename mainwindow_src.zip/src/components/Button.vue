<template>
  <!-- 这个页面是主页的banner -->
  <div class="banner">
    <div class="block">
      <el-carousel trigger="click" height="550px"  :style="{background: 'url('+bottomBg+')'}">
        <div class="bannerSelectInput">
          <el-row :gutter="10">
            <el-col :span="8">
              <div class="grid-content bg-purple-light">
                <el-input v-model="input" placeholder="请输入您要查找的技术"></el-input>
              </div>
            </el-col>
            <el-col :span="8">
              <div class="grid-content bg-purple-light">
                <el-button type="primary" icon="el-icon-search" @click="bannersearchbtn">搜索</el-button>
              </div>
            </el-col>
          </el-row>
        </div>
      </el-carousel>
    </div>
  </div>
</template>

<script>
export default {
  name: 'banner',
  data() {
    return {
      value4: '',
      input: '',
      tableData: '',
      bottomBg : require('../assets/1.jpg')
      // bannersearchbtn : ''
    }
  },
  methods: {
    bannersearchbtn() {
      if (this.input == '') {
        this.$message({
          message: '不能是空的哦，输入你要查询的内容吧',
          type: 'warning'
        })
      } else {
        console.log(this.input);
      }
    }
  }
}

</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
.el-carousel {
  /* background: url(../assets/images/banner.jpg) */
}

.el-carousel__item h3 {
  color: #475669;
  font-size: 5em;
  opacity: 0.75;
  line-height: 50px;
  margin: 0;
}
/* .el-carousel__item:nth-child(2n) {
  background-color: #99a9bf;
}

.el-carousel__item:nth-child(2n+1) {
  background-color: #d3dce6;
} */

.bannerSelectInput {
  width: 30%;
  height: 70px;
  border: 1px solid rgb(218, 218, 218);
  border-radius: 5px;
  position: relative;
  top: 60%;
  left: 35%;
  z-index: 3;
  /* banner上面的input */
  padding-top: 30px;
  padding-left: 3%;
  background-color: rgba(0, 0, 0, 0.3);
}



</style>

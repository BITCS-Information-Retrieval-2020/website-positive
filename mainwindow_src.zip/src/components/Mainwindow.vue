<template>
  <div class="mainwindow">
    <el-carousel  height="550px"  arrow="always" interval="3000">
      <div class="bannerSelectInput">
        <el-row  :gutter="0">
          <el-col :span="18">
            <div class="grid-content bg-purple-light bor">
              <el-input v-model="input" placeholder="请输入您要查找的论文">
                  <el-select v-model="value" slot="prepend" multiple placeholder="请选择主题">
                    <el-option
                      v-for="item in cities"
                      :key="item.value"
                      :label="item.label"
                      :value="item.value">
                      <span style="float: left">{{ item.label }}</span>
                      <span style="float: right; color: #8492a6; font-size: 13px">{{ item.value }}</span>
                    </el-option>
                  </el-select>
              </el-input>
            </div>
          </el-col>
          <el-col :span="2">
            <div class="grid-content bg-purple-light">
              <el-button class="bor" type="primary" icon="el-icon-search" @click="bannersearchbtn">搜索</el-button>
            </div>
          </el-col>
        </el-row>
      </div>
      <el-carousel-item v-for="(img,index) in imgList" :key="index">
        <img :src="img.url" width="100%" height="100%">
      </el-carousel-item>
    </el-carousel>
  </div>
</template>

<script>
export default {
  name: 'banner',
  methods: {
    bannersearchbtn() {
      if (this.input == '') {
        this.$message({
          message: '不能是空的哦，输入你要查询的内容吧',
          type: 'warning'
        })
      } else {
        console.log(this.input);
      }
    }
  },
  data(){
    return{
      imgList:[
        {
          url:require('../assets/1.jpg')
        },
        {
          url:require('../assets/2.jpg')
        },
        {
          url:require('../assets/3.jpg')
        },
        {
          url:require('../assets/4.jpg')
        }
      ],
      cities: [{
        value: 'Whole',
        label: '全部'
      }, {
        value: 'Title',
        label: '标题'
      }, {
        value: 'Author',
        label: '作者'
      }, {
        value: 'Abstract',
        label: '摘要'
      }],
      value: '',
      input: ''
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
.bannerSelectInput {
  width: 45%;
  height: 70px;
  border: 1px solid rgb(218, 218, 218);
  border-radius: 5px;
  position: relative;
  top: 40%;
  left: 25%;
  z-index: 3;
  /* banner上面的input */
  padding-top: 30px;
  padding-left: 30px;
  background-color: rgba(0, 0, 0, 0.3);
}
</style>

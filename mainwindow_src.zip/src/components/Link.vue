<template>
  <div>
    <h1>使用文字链接组件</h1>
    <el-link type="primary" href="http://www.baidu.com" :underline="aa">默认链接</el-link>
    <el-link type="success" href="http://www.baidu.com" target="_blank" :underline="aa">默认链接</el-link>
    <el-link type="info" disabled>默认链接</el-link>
    <el-link type="warning" icon="el-icon-platform-eleme">默认链接</el-link>
    <el-link type="danger">默认链接</el-link>
  </div>
</template>

<script>
export default {
  name: 'Link',
  data(){
    return{
      aa:false,
    }
  }
}
</script>

<style scoped>

</style>

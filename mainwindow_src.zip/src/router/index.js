import Vue from 'vue'
import Router from 'vue-router'
import Button from '../components/Button'
import Link from '../components/Link'
import Layout from '../components/Layout'
import Container from '../components/Container'
import Container_ex from '../components/Container_ex'
import Mainwindow from '../components/Mainwindow'
import BottomIndex from '../components/BottomIndex'
Vue.use(Router)

export default new Router({
  routes: [
    {path: '/button', component:Button},
    {path: '/link', component:Link},
    {path: '/layout', component:Layout},
    {path: '/container', component:Container},
    {path: '/container_ex', component:Container_ex},
    {path: '/mainwindow', component:Mainwindow},
    {path: '/buttomindex', component:BottomIndex},
  ]
})
